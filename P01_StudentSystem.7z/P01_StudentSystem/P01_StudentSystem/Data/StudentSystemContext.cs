﻿using Microsoft.EntityFrameworkCore;
using P01_StudentSystem.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace P01_StudentSystem.Data
{
    public class StudentSystemContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder builder)
        {
            builder.UseSqlServer("Server=.\\dev;Database=StudentSystem;Integrated Security=True;TrustServerCertificate=True;");
        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<Student>(e => {
                e.HasKey(x => x.StudentId);
                
                e.Property(x=>x.Name)
                .HasMaxLength(100)
                .IsUnicode(true);

                e.Property(x => x.PhoneNumber)
                .HasMaxLength(10)
                .IsFixedLength(true)
                .IsUnicode(false)
                .IsRequired(false);

                e.Property(x => x.BirthDay)
                .IsRequired(false);

                e.HasMany(x => x.HomeworkSubmissions)
                .WithOne(s => s.Student)
                .HasForeignKey(x => x.HomeworkId);


            });

            builder.Entity<StudentCourse>(e =>
            {
                e.HasKey(sc => new { sc.StudentId, sc.CourseId });

                e.HasOne(sc => sc.Student)
                .WithMany(s => s.CourseEnrollments)
                .HasForeignKey(sc => sc.StudentId);

                e.HasOne(sc => sc.Course)
                .WithMany(s => s.StudentsEnrolled)
                .HasForeignKey(sc => sc.CourseId);
            });

            builder.Entity<Course>(e =>
            {
                e.HasKey(x => x.CourseID);

                e.Property(x => x.Name)
                .HasMaxLength(80)
                .IsUnicode(true);

                e.Property(x => x.Description)
                .IsUnicode(true)
                .IsRequired(false);

                e.HasMany(x => x.Resources)
                .WithOne(x => x.Course)
                .HasForeignKey(x => x.ResourceId);

                e.HasMany(x => x.HomeworkSubmissions)
                .WithOne(x => x.Course)
                .HasForeignKey(x => x.HomeworkId);
            });

            builder.Entity<Resource>(e =>
            {
                e.HasKey(x=>x.ResourceId);

                e.Property(x => x.Name)
                .HasMaxLength(50)
                .IsUnicode(true);

                e.Property(x => x.Url)
                .IsUnicode(false);


            });

            builder.Entity<Homework>(e =>
            {
                e.HasKey(x => x.HomeworkId);

                e.Property(x => x.Content)
                .IsUnicode(false);

                
                
            });
        }
    }
}
